import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='enpersand',
    application_name='test-cicd',
    app_uid='NqFftWF45mjlfQDmks',
    org_uid='2815bb46-2b84-4896-abc5-1e8dc76467cb',
    deployment_uid='0bf3f211-85cd-4319-986b-4d3c3debb916',
    service_name='test-cicd',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'test-cicd-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
